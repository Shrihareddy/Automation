package mavenproject;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;

public class Login {
	
	WebDriver driver;
	
  @Test
  public void f() {
	  
	  
//	  System.setProperty("webdriver.chrome.driver","")
	WebDriverManager.chromedriver().setup();
	
	
	  
  }
  @BeforeMethod
  public void beforeMethod() {
  }

  @AfterMethod
  public void afterMethod() {
  }

}
